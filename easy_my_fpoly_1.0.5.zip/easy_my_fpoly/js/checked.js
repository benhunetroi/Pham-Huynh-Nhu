chrome.runtime.sendMessage("check-extension", (response) => {
    
});
